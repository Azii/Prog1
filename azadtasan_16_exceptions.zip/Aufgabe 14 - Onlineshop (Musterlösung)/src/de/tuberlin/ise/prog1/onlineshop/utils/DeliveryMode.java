/**
 * 
 */
package de.tuberlin.ise.prog1.onlineshop.utils;

/**
 * Possible delivery modes
 * @author jacobeberhardt
 *
 */
public enum DeliveryMode {
	STANDARD, EXPRESS, OVERNIGHT, LOW_COST
}
