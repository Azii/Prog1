/**
 * 
 */
package de.tuberlin.ise.prog1.onlineshop.utils;

/**
 * Supported carriers
 * @author jacobeberhardt
 *
 */
public enum Carrier {
DHL, FEDEX, UPS, HERMES, DPD
}
