package de.tuberlin.ise.prog1.onlineshop;

import de.tuberlin.ise.prog1.onlineshop.products.Product;
import de.tuberlin.ise.prog1.onlineshop.products.Shippable;
import de.tuberlin.ise.prog1.onlineshop.utils.Carrier;
import de.tuberlin.ise.prog1.onlineshop.utils.DeliveryMode;

/**
 * Instances of this class can be held in a warehouse. They contain a product and a stock level.
 * @author jacobeberhardt
 *
 */
public class WarehouseItem implements Shippable{
	private Product product;
	private int stock;

	WarehouseItem(Product product, int stock) {
		this.product = product;
		this.stock = stock;
	}

	WarehouseItem(Product product) {
		this(product, 0);
	}

	void setStock(int stock) {
		if (stock >= 0) {
			this.stock = stock;
		} else {
			System.out
					.println("Stock value could not be updated. Negative values not allowed.");
		}
	}

	public int getStock() {
		return stock;
	}

	public Product getProduct() {
		return product;
	}

	public void ship(String recipient, DeliveryMode deliveryMode, Carrier carrier, int quantity) throws Exception {
		if(quantity <= stock&&quantity > 0){
			stock = stock-quantity;
			System.out.println(quantity + " units of product with id " + product.getId() + " shipped by " + carrier + " to " + recipient + " with delivery mode " + deliveryMode);
			System.out.println("Remaining stock: " + stock);
		}else{
			String errorString;
			if (quantity <= 0)
				errorString = "smaller than or equal zero.";
			else
				errorString = "too large.";
			
			// Normalerweise sollte eine solche Exception aufgefangen werden, damit (z.B.) dem Benutzer
			// eine Fehlermeldung ausgegeben werden kann.
			throw new Exception("Quantity " + errorString);
		}
		
	}


}
