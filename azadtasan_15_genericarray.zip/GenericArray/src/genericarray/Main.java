package genericarray;
import Prog1Tools.IOTools;
public class Main {

	public static void main (String[] args)
	{
		GenericArray<Integer> gai = new GenericArray<Integer>(IOTools.readInteger("Enter array length."));
		
		int command;
		
		do {
			command = IOTools.readInteger("0 for get, 1 for put, 3 for exit.");
			
			switch(command)
			{
			case 0:
				System.out.println(gai.get(IOTools.readInteger("Enter array position you want to get the value from.")));
				break;
			case 1:
				gai.put(IOTools.readInteger("Enter int to add into the array."), IOTools.readInteger("Enter index position."));
				break;
			}
			
		}while(command != 3);
		
		GenericArray<String> gas = new GenericArray<String>(IOTools.readInteger("Enter array length."));
		
		do {
			command = IOTools.readInteger("0 for get, 1 for put, 3 for exit.");
			
			switch(command)
			{
			case 0:
				System.out.println(gas.get(IOTools.readInteger("Enter array position you want to get the value from.")));
				break;
			case 1:
				gas.put(IOTools.readString("Enter String to add into the array."), IOTools.readInteger("Enter index position."));
				break;
			}
			
		}while(command != 3);
		System.out.println("Bye!");
	}

}