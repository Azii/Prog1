package genericarray;

public class GenericArray<T>
{
	private Object [] arr;
	private int length;
	private int highestIndexPopulated;
	
	public GenericArray(int length)
	{
		arr = new Object[length];
		this.length = length;
		this.highestIndexPopulated = 0;
	}
	
	public T get(int index)
	{
		if (isInBounds(index))
			return (T)arr[index];
		else
			return null;
	}
	
	public void put(T toAdd, int index)
	{
		if (isInBounds(index))
		{
			arr[index] = toAdd;
			if (highestIndexPopulated < index)
				highestIndexPopulated = index;
		}
	}
	
	private boolean isInBounds(int index)
	{
		return (index > 0 && index < length);
	}
	
	public String toString()
	{
		String retString = "";
		for (int i = 0; i < highestIndexPopulated; i++)
		{
			if (arr[i] != null)
			retString += arr[i].toString();
		}
		return retString;
	}
}