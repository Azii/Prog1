package threads;

public class AlphabetRunnable implements Runnable {

	public void run() 
	{
		int counter = (int)'Z';
		
		while(!Thread.currentThread().isInterrupted()&&counter>=(int)'A')
		{
			System.out.println((char)counter);
			counter--;
		}
			
	}

}
