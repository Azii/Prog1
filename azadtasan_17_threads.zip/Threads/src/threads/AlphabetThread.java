package threads;

public class AlphabetThread extends Thread {

	public void run()
	{
		int counter = (int)'A';
		
		while(!isInterrupted()&&counter<=(int)'Z')
		{
			System.out.println((char)counter);
			counter++;
		}
	}
	
}
