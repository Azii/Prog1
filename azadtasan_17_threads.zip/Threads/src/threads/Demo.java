package threads;

public class Demo {

	public static void main(String[] args) {
		AlphabetThread t1 = new AlphabetThread();
		Thread t2 = new Thread(new AlphabetRunnable());
		t1.start();
		t2.start();
		try
		{
			Thread.currentThread().sleep(1000);
		}catch(InterruptedException ie)
		{
			t1.interrupt();
			t2.interrupt();
			return;
		}
		t1.interrupt();
		t2.interrupt();
		
	}

}
