package de.tuberlin.ise.prog1.protocol.enums;

/**
 * 
 * @author jacobeberhardt
 *
 */
public enum StatusCode {
	SUCCESS, ERROR, UNKNOWN_COMMAND, HASH_INVALID;

}
