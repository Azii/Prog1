package de.tuberlin.ise.prog1.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;

import Prog1Tools.IOTools;
import de.tuberlin.ise.prog1.authentication.Authenticator;
import operations.ListFiles;

/**
 * 
 * @author jacobeberhardt
 *
 */
public class Client {

	public static final String FIRST_NAME = "Azad";
	public static final String LAST_NAME = "Tasan";

	public static void main(String[] args) {

		// generate hash
		byte[] hash = Authenticator.getHash(FIRST_NAME, LAST_NAME);
		
		try {
			Socket s = new Socket("52.28.100.108", 8080);
			
			int result = 0;
			
			do{
				result = IOTools.readInt("0: download file, 1: upload file, 2: list files, 3: exit");
				
				switch(result)
				{
				case 0:
					break;
				case 1:
					break;
				case 2:
					//listFiles(s, hash);
					ListFiles.listAllFiles(s, hash);
					break;
				}
			}while(result != 3);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e)
		{
			System.out.println("Generic exception");
		}
		
		boolean exceptionOccurred = true;
		try{
			FileInputStream in = new FileInputStream("UploadFile.txt");
			exceptionOccurred = false;
		}catch(FileNotFoundException fnfe)
		{
			System.out.println("Exception occurred");
		}catch(Exception e)
		{
			System.out.println("Generic exception occurred");
		}finally
		{
			System.out.println(exceptionOccurred);
		}
		
	}
	
	private static void downloadFile(Socket s, byte [] hash)
	{
		byte [] a = new byte [17];
		
		for(int i = 0; i < 16; i++)
		{
			a[i] = hash[i];
		}
		a[16] = 1;
	}
	
	private static void listFiles(Socket s, byte [] hash)
	{
		byte [] a = new byte [17];
		
		for(int i = 0; i < 16; i++)
		{
			a[i] = hash[i];
		}
		a[16] = 2;
		
		try {
			s.getOutputStream().write(a);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		byte c;
		long counter = 0;
		long listsize = 0;
		char [] list;
		byte [] b = new byte[1];
		
		try {
			while((c = (byte)s.getInputStream().read()) != -1)
			{
				if (counter < 8)
				{
					listsize += c << (counter * 8);
					counter++;
					if (counter == 8)
					{
						b = new byte[(int)listsize];
					}
				}else if (counter - 8 < listsize)
				{
					b[(int)counter - 8] = c;
				}
				System.out.print(c);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
