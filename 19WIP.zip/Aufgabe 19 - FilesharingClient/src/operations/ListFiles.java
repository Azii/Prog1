package operations;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class ListFiles {
	
	public static void listAllFiles(Socket socket, byte []  hash)
	{
		byte [] data = createByteArray(hash);
		
		OutputStream output = null;
		InputStream input = null;
		
		try {
			output = socket.getOutputStream();
			input = socket.getInputStream();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		synchronized(output)
		{
			try {
				writeData(data, output);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		synchronized(input)
		{
			try{
				readData(input);
			}catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	private static void readData(InputStream input) throws IOException {
		byte c;
		
		long listLength = readListLength(input);
		
		
	}

	private static long readListLength(InputStream input) throws IOException {
		long listLength = 0;
		
		for (int i = 0; i < 8; i++)
		{
			listLength += (byte)input.read() << (i * 8);
		}
		
		return listLength;
	}

	private static void writeData(byte [] data, OutputStream output) throws IOException
	{
		output.write(data);
	}
	
	private static byte [] createByteArray(byte [] hash)
	{
		byte [] a = new byte[17];
		
		for (int i = 0; i < hash.length; i++)
		{
			a[i] = hash[i];
		}
		
		a[16] = 2;
		
		return a;
	}
	
}
