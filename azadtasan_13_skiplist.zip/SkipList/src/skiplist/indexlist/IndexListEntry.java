package skiplist.indexlist;

import skiplist.singlylinkedlist.SinglyLinkedListEntry;

/**
 * The ILE class. Creates the IL and stores a pointer to the n-th entry in the SLL.
 * 
 * @author azad
 *
 */

public class IndexListEntry {
	
	private static IndexListEntry first;
	
	private int position;
	private IndexListEntry next;
	private SinglyLinkedListEntry slle;
	
	public IndexListEntry()
	{
		if (IndexListEntry.first == null)
			IndexListEntry.first = this;
	}
	
	/**
	 * Creates the IL and returns the head. Constructor is private, this method has to be called to create the list.
	 * @param The total amount of ILEs.
	 * @return The first entry in the IL.
	 */
	public static IndexListEntry createIndexList(int numIndexListEntries)
	{
		if (numIndexListEntries <= 0)
		{
			System.err.println("Less than 1 max IndexListEntries are set.");
			return null;
		}
		
		IndexListEntry ile;
		ile = new IndexListEntry();
		for (int i = 0; i < numIndexListEntries - 1; i++)
		{
			ile.setNext(new IndexListEntry());
			ile = ile.getNext();
		}
		
		return IndexListEntry.first;
	}
	
	public void setNext(IndexListEntry ile)
	{
		this.next = ile;
	}
	
	public IndexListEntry getNext()
	{
		return this.next;
	}
	
	public SinglyLinkedListEntry getSLLE()
	{
		return this.slle;
	}
	
	public void setSLLE(SinglyLinkedListEntry slle)
	{
		this.slle = slle;
	}
	
	public int getPosition()
	{
		return this.position;
	}
	
	private void setPosition(int position)
	{
		this.position = position;
	}
	
	public void setPositionAndSLLE(int position, SinglyLinkedListEntry slle)
	{
		this.setPosition(position);
		this.setSLLE(slle);
	}
}
