package skiplist.indexlist;

import skiplist.singlylinkedlist.SinglyLinkedList;
import skiplist.singlylinkedlist.SinglyLinkedListEntry;

/**
 * Holds a pointer to the first ILE and provides functionality to interact with the IL.
 * 
 * @author azad
 *
 */

public class IndexList {

	private int numIndexListEntries = 4;
	private IndexListEntry head;
	
	/**
	 * Constructor. Sets the head variable and creates the IL.
	 */
	public IndexList()
	{
		head = IndexListEntry.createIndexList(numIndexListEntries);
	}
	
	/**
	 * Finds largest SLLE with value smaller than parameter passed.
	 * @param The value for which an SLLE with value smaller than is to be found.
	 * @return The SLLE that has a smaller value than the parameter passed. First entry if the value is smaller than the first entry's value.
	 */
	public SinglyLinkedListEntry findLargestEntryWithValueSmallerThan(int value)
	{
		IndexListEntry counter = this.head;
		
		while(true)
		{
			if (counter.getNext() == null)
				break;
			if (counter.getNext().getSLLE().getValue() >= value)
				break;
			if (counter.getNext().getSLLE().getValue() < value)
				counter = counter.getNext();
		}
		
		SinglyLinkedListEntry counter2 = counter.getSLLE();
		while(true)
		{
			if (counter2.getNext() == null)
				break;
			if (counter2.getNext().getValue() >= value)
				break;
			if (counter2.getNext().getValue() < value)
				counter2 = counter2.getNext();
		}
			
		return counter2;
	}
	
	/**
	 * Inserts a value into the SLL.
	 * @param The SLL object.
	 * @param The value that is to be inserted.
	 */
	public void insert(SinglyLinkedList sll, int value)
	{
		if (head.getSLLE() == null)
		{
			insertAtHead(sll, value);
		}
		else if (head.getSLLE().getValue() >= value)
		{
			insertAtHead(sll, value);
		}
		else
			insertInMiddle(sll, value);
	}
	
	/**
	 * Inserts the value at the head of the SLL.
	 * @param sll
	 * @param value
	 */
	private void insertAtHead(SinglyLinkedList sll, int value)
	{
		sll.insertAtHead(value);
		fixPointers(sll);
	}
	
	/**
	 * Inserts the value somewhere in the middle of the SLL.
	 * @param sll
	 * @param value
	 */
	private void insertInMiddle(SinglyLinkedList sll, int value)
	{
		sll.insertInMiddle(findLargestEntryWithValueSmallerThan(value), value);
		fixPointers(sll);
	}
	
	/**
	 * Fixes the ILE's pointers to the SLLEs.
	 * @param sll
	 */
	private void fixPointers(SinglyLinkedList sll)
	{	
		if (sll.getNumEntries() == 1)
		{
			fixPointersFirstEntry(sll);
		}
		else
		{
			fixPointersAfterFirstEntry(sll);
		}
	}
	
	/**
	 * Fixes the pointers if there is only one entry in the list.
	 * @param sll
	 */
	private void fixPointersFirstEntry(SinglyLinkedList sll)
	{
		IndexListEntry counter = this.head;
		
		while (true)
		{
			counter.setSLLE(sll.getHead());
			if (counter.getNext() != null)
				counter = counter.getNext();
			else
				break;
		}
	}
	
	/**
	 * Fixes the pointers if there is more than one entry in the list.
	 * @param sll
	 */
	private void fixPointersAfterFirstEntry(SinglyLinkedList sll)
	{
		IndexListEntry counter = this.head;
		
		float numSLLEOverNumILE = (float)sll.getNumEntries() / (float)numIndexListEntries;
		for (int i = 0; i < numIndexListEntries; i++)
		{
			if (i == 0)
				counter.setPositionAndSLLE(0, sll.getHead());
			else
			{
				counter.setPositionAndSLLE(positionTheILEShouldPointTo(i, numSLLEOverNumILE), sll.getEntryAtPosition(positionTheILEShouldPointTo(i, numSLLEOverNumILE)));
			}
			counter = counter.getNext();
		}
	}
	
	/**
	 * Returns the position in the SLL that the ILE should point to.
	 * @param index
	 * @param numSLLEOverNumILE
	 * @return
	 */
	private int positionTheILEShouldPointTo(int index, float numSLLEOverNumILE)
	{
		return (int)Math.floor(index * numSLLEOverNumILE);
	}
	
	/**
	 * Returns the value of the n-th entry in the list where n is the index passed.
	 * @param index
	 * @return
	 */
	public int get(int index)
	{
		IndexListEntry counter = this.head;
		while (true)
		{
			if (counter.getPosition() == index)
				break;
			if (counter.getNext() == null)
				break;
			if (counter.getNext().getPosition() > index)
				break;
			counter = counter.getNext();
		}
		SinglyLinkedListEntry counter2 = counter.getSLLE();
		for (int i = counter.getPosition(); i < index; i++)
		{
			counter2 = counter2.getNext();
		}
		return counter2.getValue();
	}
	
	/**
	 * Returns whether or not the value passed is in the SLL.
	 * @param value
	 * @return
	 */
	public boolean contains(int value)
	{
		SinglyLinkedListEntry counter = findLargestEntryWithValueSmallerThan(value);
		while(true)
		{
			if (counter.getValue() == value)
				return true;
			if (counter.getValue() > value)
				return false;
			if (counter.getNext() == null)
				return false;
			else
				counter = counter.getNext();
		}
	}
	
	/**
	 * Returns a String representation of the ILE.
	 */
	public String toString()
	{
		IndexListEntry counter = this.head;
		String retString = "";
		int counter2 = 0;
		while (true)
		{
			retString += "[ILE " + counter2 + ", points to SLLE at position " + counter.getPosition() + "] \n";
			counter2++;
			if (counter.getNext() != null)
				counter = counter.getNext();
			else
				break;
		}
		return retString;
	}
	
}
