package skiplist;

import skiplist.indexlist.IndexList;
import skiplist.singlylinkedlist.SinglyLinkedList;

/**
 * The SL. Provides an interface for a program to interact with the SL.
 * 
 * @author azad
 *
 */

public class SkipList {
	private IndexList indexList;
	private SinglyLinkedList sll;
	
	/**
	 * The constructor. Creates the IL and SLL objects.
	 */
	public SkipList()
	{
		indexList = new IndexList();
		sll = new SinglyLinkedList();
	}
	
	/**
	 * Adds an entry.
	 * @param The value the new entry is supposed to carry.
	 */
	public void addEntry(int value)
	{
		indexList.insert(sll, value);
	}
	
	/**
	 * Returns the value of the n-th SLL where n is the index passed.
	 * @param index
	 * @return
	 */
	public int get(int index)
	{
		if (index >= sll.getNumEntries() || index < 0 || sll.getNumEntries() == 0)
			return Integer.MIN_VALUE;
		else
		{
			return indexList.get(index);
		}
	}
	
	/**
	 * Returns whether or not the value passed is in the SLL.
	 * @param value
	 * @return
	 */
	public boolean contains(int value)
	{
		return indexList.contains(value);
	}
	
	/**
	 * Returns a String representation of the IndexList and of the SinglyLinkedList.
	 */
	public String toString()
	{
		return indexList.toString() + sll.toString();
	}
	
	
}
