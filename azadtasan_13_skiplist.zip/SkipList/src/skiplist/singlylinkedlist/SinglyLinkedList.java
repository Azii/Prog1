package skiplist.singlylinkedlist;

/**
 * Holds a pointer to the first SLLE, as well as provides functionality to interact with the list.
 * 
 * @author azad
 *
 */
public class SinglyLinkedList {

	private SinglyLinkedListEntry head;
	private int numEntries;
	
	/**
	 * Inserts the value at the head of the SLL.
	 * @param value
	 */
	public void insertAtHead(int value)
	{
		if (head == null)
			head = createSinglyLinkedListEntry(value);
		else
		{
			SinglyLinkedListEntry newHead = createSinglyLinkedListEntry(value);
			newHead.setNext(head);
			head = newHead;
		}
	}
	
	/**
	 * Inserts the value somewhere in the middle of the SLL.
	 * @param slle
	 * @param value
	 */
	public void insertInMiddle(SinglyLinkedListEntry slle, int value)
	{
		SinglyLinkedListEntry toInsert = createSinglyLinkedListEntry(value);
		toInsert.setNext(slle.getNext());
		slle.setNext(toInsert);
	}
	
	/**
	 * Creates a SLLE and increments the numEntries variable.
	 * @param value
	 * @return
	 */
	private SinglyLinkedListEntry createSinglyLinkedListEntry(int value)
	{
		numEntries++;
		return new SinglyLinkedListEntry(value);
	}
	
	/**
	 * Returns the SLLE at the position passed.
	 * @param position
	 * @return
	 */
	public SinglyLinkedListEntry getEntryAtPosition(int position)
	{
		if (position >= numEntries)
			return null;
		SinglyLinkedListEntry counter = this.head;
		for (int i = 0; i < position; i++)
		{
			counter = counter.getNext();
		}
		return counter;
	}
	
	/**
	 * Returns a String representation of the SLL.
	 */
	public String toString()
	{
		String retString = "\n";
		SinglyLinkedListEntry counter = head;
		int counter2 = 0;
		while (true)
		{
			retString += "[SLLE " + counter2 + ", has value " + counter.getValue() + "]\n";
			if (counter.getNext() == null)
				break;
			else
			{
				counter = counter.getNext();
				counter2++;
			}
		}
		return retString;
	}
	
	/**
	 * Getters and setters.
	 */
	
	public int getNumEntries()
	{
		return this.numEntries;
	}
	
	public SinglyLinkedListEntry getHead()
	{
		return this.head;
	}
	
}
