package skiplist.singlylinkedlist;

/**
 * A SLLE. Stores a value of type int.
 * 
 * @author azad
 *
 */

public class SinglyLinkedListEntry {

	private int value;
	private SinglyLinkedListEntry next;
	
	/**
	 * Constructor, sets the value variable to parameter passed to this function.
	 * @param value
	 */
	public SinglyLinkedListEntry(int value)
	{
		this.value = value;
	}
	
	/**
	 * Getters and setters.
	 */
	
	public int getValue()
	{
		return this.value;
	}
	
	public void setValue(int value)
	{
		this.value = value;
	}
	
	public SinglyLinkedListEntry getNext()
	{
		return this.next;
	}
	
	public void setNext(SinglyLinkedListEntry next)
	{
		this.next = next;
	}
	
}
