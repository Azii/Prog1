package skiplist;
import Prog1Tools.IOTools;

/**
 * The class that is first run when the program is started. Tested and written using OpenJDK 1.8.0 64-bit.
 * 
 * @author azad
 *
 */

public class Main {
	
	/**
	 * Main method. Provides an interface to test/use the SL.
	 * @param args
	 */
	public static void main(String[] args) {
		SkipList sl = new SkipList();
		
		int result;
		
		do
		{
			result = IOTools.readInteger("Enter 0 to add a number, 1 to get the value of the n-th SLLE, 2 to check if the list contains an element with value n"
					+ ", 3 to get a string representation of the lists or 4 to exit.");
			
			switch(result)
			{
			case 0:
				sl.addEntry(IOTools.readInteger("Enter the integer that you want to add into the list."));
				break;
			case 1:
				System.out.println(sl.get(IOTools.readInteger("Enter the index at which the element's value you want to get resides "
						+ "(returns Integer.MIN_VALUE if the index is out of bounds).")));
				break;
			case 2:
				System.out.println(sl.contains(IOTools.readInteger("Enter the integer you want to check existence in the list for.")));
				break;
			case 3:
				System.out.println(sl.toString());
				break;
			}
		} while(result != 4);
		
		System.out.println("Goodbye!");
	}

}
