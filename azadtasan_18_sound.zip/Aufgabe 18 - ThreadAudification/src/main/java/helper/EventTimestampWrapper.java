package helper;

import de.tuberlin.ise.prog1.midi.MidiSoundEvent;

public class EventTimestampWrapper {

	private MidiSoundEvent event;
	private long startTimestamp;
	private long endTimestamp;
	private boolean isPlaying;
	
	public EventTimestampWrapper(MidiSoundEvent event, long startTimestamp)
	{
		this.event = event;
		this.startTimestamp = startTimestamp;
		this.endTimestamp = this.startTimestamp + event.durationInMs;
		this.isPlaying = false;
	}
	
	public MidiSoundEvent getEvent()
	{
		return this.event;
	}
	
	public long getStartTimestamp()
	{
		return this.startTimestamp;
	}
	
	public long getEndTimestamp()
	{
		return this.endTimestamp;
	}
	
	public void startPlaying()
	{
		this.isPlaying = true;
	}
	
	public boolean isPlaying()
	{
		return this.isPlaying;
	}
	
}
