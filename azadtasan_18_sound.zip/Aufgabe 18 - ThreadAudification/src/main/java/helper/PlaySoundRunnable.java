package helper;

import java.util.ArrayList;

import de.tuberlin.ise.prog1.midi.MidiSoundEvent;
import de.tuberlin.ise.prog1.midi.devices.MidiOutput;

public class PlaySoundRunnable implements Runnable{

	private ArrayList<EventTimestampWrapper> al;
	private MidiOutput midioutput;
	
	public PlaySoundRunnable(ArrayList<EventTimestampWrapper> al, MidiOutput midioutput)
	{
		this.al = al;
		this.midioutput = midioutput;
	}
	
	public void run()
	{
		long currentTime;
		ArrayList<EventTimestampWrapper> removeIndices = new ArrayList<>();
		
		while(true && !Thread.currentThread().isInterrupted())
		{
			currentTime = System.currentTimeMillis();
			
			synchronized(al)
			{
				for (EventTimestampWrapper etw : al)
				{
					if (etw.getStartTimestamp() <= currentTime && etw.isPlaying() == false)
					{
						MidiSoundEvent event = etw.getEvent();
						midioutput.startNote(event.channel, event.tone, event.volume);
						etw.startPlaying();
					}else if(etw.getEndTimestamp() <= currentTime)
					{
						MidiSoundEvent event = etw.getEvent();
						midioutput.stopNote(event.channel, event.tone);
						removeIndices.add(etw);
					}
				}
				
				for (EventTimestampWrapper etw : removeIndices)
				{
					al.remove(etw);
				}
			}
			removeIndices.clear();
		}
	}
	
}
