/**
 * 
 */
package de.tuberlin.ise.prog1.midi;

import java.util.ArrayList;

import de.tuberlin.ise.prog1.midi.devices.MidiOutput;
import de.tuberlin.ise.prog1.midi.instruments.Instrument;
import helper.EventTimestampWrapper;
import helper.PlaySoundRunnable;

/**
 * @author Dave
 *
 */
public class MidiScheduler {

	/** output device that is used */
	private final MidiOutput midioutput;

	private final int numThreads = 4;
	
	private Thread [] threads = new Thread[numThreads];
	
	private Thread playSound;
	
	private int lastUsedThreadIndex = 0;
	
	private ArrayList<EventTimestampWrapper> al = new ArrayList<>();
	
	/**
	 * @param midioutput
	 */
	public MidiScheduler(MidiOutput midioutput) {
		super();
		this.midioutput = midioutput;
		// ...
	}

	/**
	 * terminates playback
	 */
	public void terminate() {
		playSound.interrupt();
		midioutput.terminate();
	}

	/**
	 * plays the specified note
	 * 
	 * @param startTimestamp
	 *            when to play the note
	 * @param note
	 *            will be played
	 * 
	 */
	public void play(long startTimestamp, MidiSoundEvent event) {
		synchronized(al){
			int prevLen = al.size();
			al.add(new EventTimestampWrapper(event, startTimestamp));
			if (prevLen == 0 && al.size() == 1)
			{
				startPlayback();
			}
		}
		// midioutput.startNote(event.channel, event.tone, event.volume); So wird der Ton gestartet.
		// midioutput.stopNote(event.channel, event.tone); So wird der Ton beendet.
	}
	
	private void startPlayback()
	{
		playSound = new Thread(new PlaySoundRunnable(al, midioutput));
		playSound.start();
	}

	private void incrementLastThreadUsed()
	{
		if (++lastUsedThreadIndex == numThreads)
		{
			lastUsedThreadIndex = 0;
		}
	}
	
	/**
	 * changes the sound of the specified channel to the specified instrument
	 * 
	 * @param instrument
	 * @param channel
	 */
	public void changeInstrument(Instrument instrument, int channel) {
		midioutput.setInstrument(channel, instrument);
	}

	
}
